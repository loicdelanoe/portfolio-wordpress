# Portfolio
Ce projet est réalisé dans le cadre des cours de la HEPL.
# Lancer le projet
- Mettre le thème dans le dossier wp-content/themes
- Lancer la commande `npx mix` ou `npx mix watch`
- Lancer wordpress