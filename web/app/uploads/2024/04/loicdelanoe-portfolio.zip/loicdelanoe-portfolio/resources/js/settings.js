export const settings = {
    showUpClass: 'show-up',
    NoOpacityClass: 'no-opacity',
    slideLeftClass: "slide-left",
    slideRightClass: "slide-right"
};
